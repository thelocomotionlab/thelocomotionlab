import { useEffect, useState } from "react";
import { X } from "lucide-react";
import articles from "../content/articles.json";
import { projects } from "../content/projects";

export default function SearchOverlay({ open, onClose }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState({ arts: [], pros: [] });

  // filtrage simple : titre + tags + résumé
  useEffect(() => {
    if (!query) {
      setResults({ arts: [], pros: [] });
      return;
    }

    const q = query.toLowerCase();

    const arts = articles.filter(
      (a) =>
        a.title.toLowerCase().includes(q) ||
        (a.tags || []).some((t) => t.toLowerCase().includes(q))
    );

    const pros = projects.filter(
      (p) =>
        p.title.toLowerCase().includes(q) ||
        (p.summary || "").toLowerCase().includes(q)
    );

    setResults({ arts, pros });
  }, [query]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Overlay flou */}
      <div
        className="flex-1 backdrop-blur-sm bg-black/40"
        onClick={onClose}
      />

      {/* Panneau recherche */}
      <div className="w-full sm:w-[480px] h-full bg-white shadow-xl animate-slideIn flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-sans font-semibold">Recherche</h2>
          <button onClick={onClose} aria-label="Fermer">
            <X size={24} />
          </button>
        </div>

        {/* Champ recherche */}
        <div className="p-4">
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Tape un mot-clé…"
            autoFocus
            className="w-full px-4 py-2 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-brand-accent"
          />
        </div>

        {/* Résultats */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {results.arts.length > 0 && (
            <div>
              <h3 className="text-md font-semibold mb-2">Carnets</h3>
              <ul className="space-y-2">
                {results.arts.map((a) => (
                  <li key={a.slug}>
                    <a
                      href={`/articles/${a.slug}`}
                      className="block hover:underline"
                      onClick={onClose}
                    >
                      {a.title}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {results.pros.length > 0 && (
            <div>
              <h3 className="text-md font-semibold mb-2">Projets</h3>
              <ul className="space-y-2">
                {results.pros.map((p) => (
                  <li key={p.title}>
                    <a
                      href="/projets"
                      className="block hover:underline"
                      onClick={onClose}
                    >
                      {p.title}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {query && results.arts.length === 0 && results.pros.length === 0 && (
            <p className="text-gray-500">Aucun résultat pour « {query} ».</p>
          )}
        </div>
      </div>
    </div>
  );
}
