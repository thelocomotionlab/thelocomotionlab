---
title: "Trail en sandales : mon premier 100 miles"
date: "2025-09-21"
tags: ["ultra-trail", "minimalisme", "expérience perso"]
# cover: "/images/grand-raid.jpg"
type: "recit"
---


Avril 2020, en période de confinement, ma soeur médecin du sport me conseille, pour tuer l'ennui, de feuilleter "la santé par la course à pieds", écrit par Blaise Dubois, le fondateur de la Clinique du Coureur. Malgré mon aversion pour la course à pieds, ma curiosité est piquée lorsque je découvre cette conversation fictive entre Lucie et un être humain moderne. J'y apprends que l'évolution a affûté Homo Sapiens au point d'en faire l'athlète le plus endurant en course à pieds de tout le reigne animal. Je comprends également que le pied humain est un véritable chef d'oeuvre de bio-ingéniérie, dynamique et robuste, pouvant soutenir le poids d'une personne sur des dizaines et des dizaines de milliers de pas. Stupéfait par cette prise de conscience, je découvre quelques pages plus loin,

## Le départ
Ambiance, sensations du matin, météo, l’excitation sur la ligne.

## Le déroulé
- **Km 0 → 50** : sensations physiques, paysages, rencontres.
- **Km 50 → 100** : difficultés, doutes, moments de flow.
- **Km 100 → 150** : douleurs, respiration, stratégies mentales.
- **Km 150 → 166** : la fracture de fatigue, la décision d’arrêter.

## Les moments forts
Quelques anecdotes marquantes ou visuelles (lever de soleil, encouragements, hallucinations…).

> Citation manuscrite pour figer une pensée :  
> *"À ce moment-là, j’ai compris que mon moteur était intact mais que mon squelette n’était pas prêt."*

## Le retour à froid
Analyse de ce que j’ai appris, ressentis une fois reposé, ce que j’en retire.

## Conclusion
Comment cette expérience s’inscrit dans ma trajectoire au Locomotion Lab.
