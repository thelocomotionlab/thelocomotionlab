---
title: "UTMB en sandales"
date: "2025-08-20"
status: "à venir"
description: "Préparation, protocole d’entraînement, stratégies de course, retour d’expérience."
cover: "/images/projets/utmb.jpg"
---

# Journal du projet


